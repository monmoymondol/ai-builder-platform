import React, { useState } from 'react';

const ModelConfigurator = () => {
  const [modelConfig, setModelConfig] = useState({
    name: '',
    type: 'neural_network',
    architecture: 'transformer',
    layers: 12,
    hiddenSize: 768,
    attentionHeads: 12,
    learningRate: 0.001,
    batchSize: 32,
    epochs: 100,
    optimizer: 'adam'
  });

  const [isBuilding, setIsBuilding] = useState(false);

  const modelTypes = [
    { value: 'neural_network', label: 'Neural Network', icon: '🧠', color: 'from-blue-500 to-purple-500' },
    { value: 'transformer', label: 'Transformer', icon: '🔄', color: 'from-purple-500 to-pink-500' },
    { value: 'cnn', label: 'Convolutional Neural Network', icon: '🖼️', color: 'from-green-500 to-blue-500' },
    { value: 'rnn', label: 'Recurrent Neural Network', icon: '🔁', color: 'from-yellow-500 to-orange-500' },
    { value: 'gan', label: 'Generative Adversarial Network', icon: '🎭', color: 'from-pink-500 to-red-500' }
  ];

  const architectures = {
    neural_network: ['feedforward', 'deep_neural_network'],
    transformer: ['transformer', 'bert', 'gpt', 'roberta'],
    cnn: ['lenet', 'alexnet', 'vgg', 'resnet', 'inception'],
    rnn: ['vanilla_rnn', 'lstm', 'gru', 'bidirectional'],
    gan: ['vanilla_gan', 'dcgan', 'wgan', 'stylegan']
  };

  const handleInputChange = (field, value) => {
    setModelConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleBuildModel = async () => {
    setIsBuilding(true);
    // Simulate model building process
    setTimeout(() => {
      setIsBuilding(false);
      alert(`AI Model "${modelConfig.name}" configuration saved successfully!`);
    }, 2000);
  };

  const selectedModelType = modelTypes.find(type => type.value === modelConfig.type);

  return (
    <div className="space-y-8">
      {/* Header with animated gradient */}
      <div className="relative overflow-hidden bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-2xl p-8 text-white">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative z-10 flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-bold mb-2">AI Model Configuration</h2>
            <p className="text-purple-100">Design and configure your AI model architecture</p>
          </div>
          <button
            onClick={handleBuildModel}
            disabled={!modelConfig.name || isBuilding}
            className={`px-8 py-4 rounded-2xl font-semibold text-lg transition-all duration-300 transform hover:scale-105 ${
              isBuilding 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-white text-purple-600 hover:bg-purple-50 shadow-lg hover:shadow-xl'
            }`}
          >
            {isBuilding ? (
              <div className="flex items-center space-x-2">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-purple-600"></div>
                <span>Building...</span>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <span>🚀</span>
                <span>Build Model</span>
              </div>
            )}
          </button>
        </div>
      </div>

      {/* Model Type Selection with Cards */}
      <div className="space-y-6">
        <h3 className="text-2xl font-bold text-gray-800">Choose Model Type</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {modelTypes.map((type) => (
            <div
              key={type.value}
              onClick={() => handleInputChange('type', type.value)}
              className={`relative cursor-pointer group transition-all duration-300 transform hover:scale-105 ${
                modelConfig.type === type.value ? 'ring-4 ring-purple-400' : ''
              }`}
            >
              <div className={`absolute inset-0 bg-gradient-to-r ${type.color} rounded-2xl opacity-10 group-hover:opacity-20 transition-opacity`}></div>
              <div className="relative bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl border-2 border-transparent hover:border-purple-200">
                <div className="text-4xl mb-3">{type.icon}</div>
                <h4 className="font-bold text-lg text-gray-800 mb-2">{type.label}</h4>
                <div className={`w-full h-1 bg-gradient-to-r ${type.color} rounded-full`}></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Basic Configuration */}
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100 hover-lift">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl text-white text-xl">
              ⚙️
            </div>
            <h3 className="text-2xl font-bold text-gray-800">Basic Configuration</h3>
          </div>
          
          <div className="space-y-6">
            <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-3">Model Name</label>
              <input
                type="text"
                value={modelConfig.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors group-hover:border-purple-300"
                placeholder="Enter a unique model name"
              />
            </div>

            <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-3">Architecture</label>
              <select
                value={modelConfig.architecture}
                onChange={(e) => handleInputChange('architecture', e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500 transition-colors group-hover:border-purple-300"
              >
                {architectures[modelConfig.type]?.map(arch => (
                  <option key={arch} value={arch}>
                    {arch.replace('_', ' ').toUpperCase()}
                  </option>
                ))}
              </select>
            </div>

            {selectedModelType && (
              <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{selectedModelType.icon}</span>
                  <div>
                    <p className="font-semibold text-purple-800">Selected: {selectedModelType.label}</p>
                    <p className="text-sm text-purple-600">Architecture: {modelConfig.architecture.toUpperCase()}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Advanced Parameters */}
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100 hover-lift">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-3 bg-gradient-to-r from-green-500 to-blue-500 rounded-xl text-white text-xl">
              🔧
            </div>
            <h3 className="text-2xl font-bold text-gray-800">Advanced Parameters</h3>
          </div>
          
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Layers</label>
                <input
                  type="number"
                  value={modelConfig.layers}
                  onChange={(e) => handleInputChange('layers', parseInt(e.target.value))}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500 transition-colors"
                />
              </div>
              <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Hidden Size</label>
                <input
                  type="number"
                  value={modelConfig.hiddenSize}
                  onChange={(e) => handleInputChange('hiddenSize', parseInt(e.target.value))}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500 transition-colors"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Learning Rate</label>
                <input
                  type="number"
                  step="0.0001"
                  value={modelConfig.learningRate}
                  onChange={(e) => handleInputChange('learningRate', parseFloat(e.target.value))}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500 transition-colors"
                />
              </div>
              <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Batch Size</label>
                <input
                  type="number"
                  value={modelConfig.batchSize}
                  onChange={(e) => handleInputChange('batchSize', parseInt(e.target.value))}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500 transition-colors"
                />
              </div>
            </div>

            <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-2">Optimizer</label>
              <select
                value={modelConfig.optimizer}
                onChange={(e) => handleInputChange('optimizer', e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-green-500 transition-colors"
              >
                <option value="adam">Adam</option>
                <option value="sgd">SGD</option>
                <option value="rmsprop">RMSprop</option>
                <option value="adagrad">Adagrad</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Model Preview with Animation */}
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-3 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl text-white text-xl">
            👁️
          </div>
          <h3 className="text-2xl font-bold text-gray-800">Model Preview</h3>
        </div>
        
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 font-mono text-sm overflow-hidden">
          <div className="flex items-center space-x-2 mb-4">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-gray-400 ml-4">model-config.json</span>
          </div>
          <div className="text-green-400 animate-fadeIn">
            <pre className="whitespace-pre-wrap">{JSON.stringify(modelConfig, null, 2)}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModelConfigurator;