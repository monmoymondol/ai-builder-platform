import React, { useState } from 'react';

const ModelConfigurator = () => {
  const [modelConfig, setModelConfig] = useState({
    name: '',
    type: 'neural_network',
    architecture: 'transformer',
    layers: 12,
    hiddenSize: 768,
    attentionHeads: 12,
    learningRate: 0.001,
    batchSize: 32,
    epochs: 100,
    optimizer: 'adam'
  });

  const [isBuilding, setIsBuilding] = useState(false);

  const modelTypes = [
    { value: 'neural_network', label: 'Neural Network' },
    { value: 'transformer', label: 'Transformer' },
    { value: 'cnn', label: 'Convolutional Neural Network' },
    { value: 'rnn', label: 'Recurrent Neural Network' },
    { value: 'gan', label: 'Generative Adversarial Network' }
  ];

  const architectures = {
    neural_network: ['feedforward', 'deep_neural_network'],
    transformer: ['transformer', 'bert', 'gpt', 'roberta'],
    cnn: ['lenet', 'alexnet', 'vgg', 'resnet', 'inception'],
    rnn: ['vanilla_rnn', 'lstm', 'gru', 'bidirectional'],
    gan: ['vanilla_gan', 'dcgan', 'wgan', 'stylegan']
  };

  const handleInputChange = (field, value) => {
    setModelConfig(prev => ({ ...prev, [field]: value }));
  };

  const handleBuildModel = async () => {
    setIsBuilding(true);
    // Simulate model building process
    setTimeout(() => {
      setIsBuilding(false);
      alert(`AI Model "${modelConfig.name}" configuration saved successfully!`);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">AI Model Configuration</h2>
        <button
          onClick={handleBuildModel}
          disabled={!modelConfig.name || isBuilding}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isBuilding ? '🔄 Building...' : '🚀 Build Model'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Basic Configuration */}
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-4">Basic Configuration</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Model Name</label>
              <input
                type="text"
                value={modelConfig.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter model name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Model Type</label>
              <select
                value={modelConfig.type}
                onChange={(e) => handleInputChange('type', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {modelTypes.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Architecture</label>
              <select
                value={modelConfig.architecture}
                onChange={(e) => handleInputChange('architecture', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {architectures[modelConfig.type]?.map(arch => (
                  <option key={arch} value={arch}>{arch.replace('_', ' ').toUpperCase()}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Advanced Parameters */}
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold mb-4">Advanced Parameters</h3>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Layers</label>
                <input
                  type="number"
                  value={modelConfig.layers}
                  onChange={(e) => handleInputChange('layers', parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Hidden Size</label>
                <input
                  type="number"
                  value={modelConfig.hiddenSize}
                  onChange={(e) => handleInputChange('hiddenSize', parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Learning Rate</label>
                <input
                  type="number"
                  step="0.0001"
                  value={modelConfig.learningRate}
                  onChange={(e) => handleInputChange('learningRate', parseFloat(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Batch Size</label>
                <input
                  type="number"
                  value={modelConfig.batchSize}
                  onChange={(e) => handleInputChange('batchSize', parseInt(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Optimizer</label>
              <select
                value={modelConfig.optimizer}
                onChange={(e) => handleInputChange('optimizer', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="adam">Adam</option>
                <option value="sgd">SGD</option>
                <option value="rmsprop">RMSprop</option>
                <option value="adagrad">Adagrad</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Model Preview */}
      <div className="bg-white border rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Model Preview</h3>
        <div className="bg-gray-100 rounded-lg p-4 font-mono text-sm">
          <pre>{JSON.stringify(modelConfig, null, 2)}</pre>
        </div>
      </div>
    </div>
  );
};

export default ModelConfigurator;