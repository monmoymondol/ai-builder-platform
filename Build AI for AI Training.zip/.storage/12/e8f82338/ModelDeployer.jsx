import React, { useState } from 'react';

const ModelDeployer = () => {
  const [deployedModels, setDeployedModels] = useState([
    {
      id: 1,
      name: 'Text Generator v2.1',
      type: 'Transformer',
      status: 'Active',
      endpoint: 'https://api.aibuilder.com/v1/text-gen',
      requests: 15420,
      uptime: '99.9%',
      deployDate: '2024-08-15'
    },
    {
      id: 2,
      name: 'Image Classifier Pro',
      type: 'CNN',
      status: 'Active',
      endpoint: 'https://api.aibuilder.com/v1/image-classify',
      requests: 8932,
      uptime: '99.7%',
      deployDate: '2024-08-20'
    },
    {
      id: 3,
      name: 'Speech Recognizer',
      type: 'RNN',
      status: 'Maintenance',
      endpoint: 'https://api.aibuilder.com/v1/speech-rec',
      requests: 5621,
      uptime: '98.5%',
      deployDate: '2024-08-25'
    }
  ]);

  const [testInput, setTestInput] = useState('');
  const [testOutput, setTestOutput] = useState('');
  const [selectedModel, setSelectedModel] = useState('');
  const [isDeploying, setIsDeploying] = useState(false);
  const [isTesting, setIsTesting] = useState(false);

  const availableModels = [
    { id: 'model1', name: 'GPT-Style Transformer', status: 'Ready' },
    { id: 'model2', name: 'Image Classifier CNN', status: 'Ready' },
    { id: 'model3', name: 'Speech Recognition RNN', status: 'Training' },
    { id: 'model4', name: 'Sentiment Analyzer', status: 'Ready' }
  ];

  const handleDeploy = async () => {
    if (!selectedModel) return;
    
    setIsDeploying(true);
    // Simulate deployment process
    setTimeout(() => {
      const newModel = {
        id: deployedModels.length + 1,
        name: availableModels.find(m => m.id === selectedModel)?.name || 'New Model',
        type: 'Custom',
        status: 'Active',
        endpoint: `https://api.aibuilder.com/v1/model-${deployedModels.length + 1}`,
        requests: 0,
        uptime: '100%',
        deployDate: new Date().toISOString().split('T')[0]
      };
      setDeployedModels(prev => [...prev, newModel]);
      setIsDeploying(false);
      setSelectedModel('');
    }, 3000);
  };

  const handleTest = async () => {
    if (!testInput.trim()) return;
    
    setIsTesting(true);
    // Simulate API call
    setTimeout(() => {
      const mockResponses = [
        'This is a generated response based on your input.',
        'Classification: Positive sentiment (confidence: 92%)',
        'Detected objects: car (85%), person (78%), building (91%)',
        'Translation: "Hello, how are you today?"',
        'Summary: The input text discusses AI model deployment strategies.'
      ];
      setTestOutput(mockResponses[Math.floor(Math.random() * mockResponses.length)]);
      setIsTesting(false);
    }, 2000);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Active': return 'bg-green-100 text-green-800';
      case 'Maintenance': return 'bg-yellow-100 text-yellow-800';
      case 'Offline': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Model Deployment</h2>
        <button
          onClick={handleDeploy}
          disabled={!selectedModel || isDeploying}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
        >
          {isDeploying ? '🚀 Deploying...' : '🚀 Deploy Model'}
        </button>
      </div>

      {/* Deployment Section */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Deploy New Model</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Model to Deploy</label>
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Choose a model...</option>
              {availableModels.map(model => (
                <option 
                  key={model.id} 
                  value={model.id}
                  disabled={model.status !== 'Ready'}
                >
                  {model.name} ({model.status})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Deployment Configuration</label>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="auto-scale" className="mr-2" defaultChecked />
                <label htmlFor="auto-scale" className="text-sm">Auto-scaling enabled</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="monitoring" className="mr-2" defaultChecked />
                <label htmlFor="monitoring" className="text-sm">Performance monitoring</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="cache" className="mr-2" />
                <label htmlFor="cache" className="text-sm">Response caching</label>
              </div>
            </div>
          </div>
        </div>

        {isDeploying && (
          <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-3"></div>
              <span className="text-blue-800">Deploying model to production environment...</span>
            </div>
          </div>
        )}
      </div>

      {/* Deployed Models */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold">Deployed Models</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Model Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Requests
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Uptime
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {deployedModels.map((model) => (
                <tr key={model.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{model.name}</div>
                    <div className="text-sm text-gray-500">{model.endpoint}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {model.type}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(model.status)}`}>
                      {model.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {model.requests.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {model.uptime}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className="text-blue-600 hover:text-blue-900 mr-3">Monitor</button>
                    <button className="text-yellow-600 hover:text-yellow-900 mr-3">Update</button>
                    <button className="text-red-600 hover:text-red-900">Stop</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Model Testing */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Test Deployed Models</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Input</label>
            <textarea
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-32"
              placeholder="Enter test input for your model..."
            />
            <button
              onClick={handleTest}
              disabled={!testInput.trim() || isTesting}
              className="mt-3 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 transition-colors"
            >
              {isTesting ? '🔄 Testing...' : '🧪 Test Model'}
            </button>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Output</label>
            <div className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 h-32 overflow-y-auto">
              {testOutput || 'Model output will appear here...'}
            </div>
            <div className="mt-3 text-sm text-gray-500">
              Response time: {isTesting ? 'Testing...' : '245ms'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModelDeployer;