import React, { useState } from 'react';
import StatsCard from './StatsCard';
import ModelConfigurator from './ModelConfigurator';
import DataManager from './DataManager';
import TrainingMonitor from './TrainingMonitor';
import ModelDeployer from './ModelDeployer';
import ResourceMonitor from './ResourceMonitor';

const AIBuilder = () => {
  const [activeTab, setActiveTab] = useState('configure');
  const [modelStats, setModelStats] = useState({
    totalModels: 12,
    activeTraining: 3,
    deployedModels: 8,
    datasetSize: '2.4TB'
  });

  const tabs = [
    { id: 'configure', label: 'Model Configuration', icon: '🧠', color: 'from-purple-500 to-pink-500' },
    { id: 'data', label: 'Data Management', icon: '📊', color: 'from-blue-500 to-cyan-500' },
    { id: 'training', label: 'Training Monitor', icon: '⚡', color: 'from-yellow-500 to-orange-500' },
    { id: 'deploy', label: 'Model Deployment', icon: '🚀', color: 'from-green-500 to-emerald-500' },
    { id: 'resources', label: 'Resource Monitor', icon: '💻', color: 'from-indigo-500 to-purple-500' }
  ];

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'configure':
        return <ModelConfigurator />;
      case 'data':
        return <DataManager />;
      case 'training':
        return <TrainingMonitor />;
      case 'deploy':
        return <ModelDeployer />;
      case 'resources':
        return <ResourceMonitor />;
      default:
        return <ModelConfigurator />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Hero Section with Animated Background */}
      <div className="relative overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 rounded-3xl p-8 text-white">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
          <div className="absolute top-0 right-0 w-72 h-72 bg-yellow-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
          <div className="absolute -bottom-8 left-20 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
        </div>
        <div className="relative z-10">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
            AI Builder Platform
          </h1>
          <p className="text-xl md:text-2xl text-purple-100 mb-6">
            Create, Train, and Deploy AI Models with Unprecedented Ease
          </p>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-4 py-2 backdrop-blur-sm">
              <span className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></span>
              <span className="text-sm">System Online</span>
            </div>
            <div className="flex items-center space-x-2 bg-white bg-opacity-20 rounded-full px-4 py-2 backdrop-blur-sm">
              <span className="text-sm">🔥 High Performance Computing</span>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="group relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl transform group-hover:scale-105 transition-transform duration-300"></div>
          <div className="relative bg-white rounded-2xl p-6 m-0.5 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Total Models</p>
                <p className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  {modelStats.totalModels}
                </p>
                <p className="text-sm text-green-600 font-medium">+2 this week</p>
              </div>
              <div className="text-4xl animate-bounce">🧠</div>
            </div>
          </div>
        </div>

        <div className="group relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-2xl transform group-hover:scale-105 transition-transform duration-300"></div>
          <div className="relative bg-white rounded-2xl p-6 m-0.5 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Active Training</p>
                <p className="text-3xl font-bold bg-gradient-to-r from-yellow-500 to-orange-500 bg-clip-text text-transparent">
                  {modelStats.activeTraining}
                </p>
                <p className="text-sm text-blue-600 font-medium">3 in progress</p>
              </div>
              <div className="text-4xl animate-spin">⚡</div>
            </div>
          </div>
        </div>

        <div className="group relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl transform group-hover:scale-105 transition-transform duration-300"></div>
          <div className="relative bg-white rounded-2xl p-6 m-0.5 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Deployed Models</p>
                <p className="text-3xl font-bold bg-gradient-to-r from-green-500 to-emerald-500 bg-clip-text text-transparent">
                  {modelStats.deployedModels}
                </p>
                <p className="text-sm text-green-600 font-medium">+1 today</p>
              </div>
              <div className="text-4xl animate-pulse">🚀</div>
            </div>
          </div>
        </div>

        <div className="group relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-pink-500 to-rose-500 rounded-2xl transform group-hover:scale-105 transition-transform duration-300"></div>
          <div className="relative bg-white rounded-2xl p-6 m-0.5 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Dataset Size</p>
                <p className="text-3xl font-bold bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">
                  {modelStats.datasetSize}
                </p>
                <p className="text-sm text-green-600 font-medium">+500GB this month</p>
              </div>
              <div className="text-4xl animate-bounce">📊</div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Navigation Tabs */}
      <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden">
        <div className="border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
          <nav className="flex space-x-0 px-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative py-6 px-6 font-medium text-sm transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'text-white'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {activeTab === tab.id && (
                  <div className={`absolute inset-0 bg-gradient-to-r ${tab.color} rounded-t-2xl transform transition-all duration-300`}></div>
                )}
                <div className="relative z-10 flex items-center space-x-3">
                  <span className="text-2xl">{tab.icon}</span>
                  <span>{tab.label}</span>
                </div>
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-white rounded-full"></div>
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* Active Component with Animation */}
        <div className="p-8 min-h-screen">
          <div className="animate-fadeIn">
            {renderActiveComponent()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIBuilder;