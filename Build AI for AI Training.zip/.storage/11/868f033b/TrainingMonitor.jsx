import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';

const TrainingMonitor = () => {
  const [trainingData, setTrainingData] = useState([]);
  const [activeModels, setActiveModels] = useState([
    {
      id: 1,
      name: 'GPT-Style Transformer',
      status: 'Training',
      progress: 65,
      epoch: 65,
      totalEpochs: 100,
      loss: 0.234,
      accuracy: 87.5,
      eta: '2h 15m'
    },
    {
      id: 2,
      name: 'Image Classifier CNN',
      status: 'Training',
      progress: 42,
      epoch: 42,
      totalEpochs: 100,
      loss: 0.456,
      accuracy: 92.1,
      eta: '3h 45m'
    },
    {
      id: 3,
      name: 'Speech Recognition RNN',
      status: 'Completed',
      progress: 100,
      epoch: 100,
      totalEpochs: 100,
      loss: 0.123,
      accuracy: 95.8,
      eta: 'Completed'
    }
  ]);

  // Simulate real-time training data
  useEffect(() => {
    const generateTrainingData = () => {
      const data = [];
      for (let i = 0; i <= 100; i += 5) {
        data.push({
          epoch: i,
          trainLoss: Math.max(0.1, 2.5 * Math.exp(-i / 30) + Math.random() * 0.1),
          valLoss: Math.max(0.12, 2.7 * Math.exp(-i / 35) + Math.random() * 0.1),
          trainAcc: Math.min(98, 100 * (1 - Math.exp(-i / 25)) + Math.random() * 2),
          valAcc: Math.min(96, 100 * (1 - Math.exp(-i / 30)) + Math.random() * 2)
        });
      }
      return data;
    };

    setTrainingData(generateTrainingData());

    // Simulate progress updates
    const interval = setInterval(() => {
      setActiveModels(prev => prev.map(model => {
        if (model.status === 'Training' && model.progress < 100) {
          const newProgress = Math.min(100, model.progress + Math.random() * 2);
          return {
            ...model,
            progress: newProgress,
            epoch: Math.floor(newProgress),
            loss: Math.max(0.1, model.loss - Math.random() * 0.01),
            accuracy: Math.min(98, model.accuracy + Math.random() * 0.5)
          };
        }
        return model;
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case 'Training': return 'bg-blue-100 text-blue-800';
      case 'Completed': return 'bg-green-100 text-green-800';
      case 'Failed': return 'bg-red-100 text-red-800';
      case 'Paused': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Training Monitor</h2>
        <div className="flex space-x-3">
          <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            ▶️ Start Training
          </button>
          <button className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors">
            ⏸️ Pause All
          </button>
          <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
            ⏹️ Stop All
          </button>
        </div>
      </div>

      {/* Active Training Models */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {activeModels.map((model) => (
          <div key={model.id} className="bg-white rounded-lg shadow p-6 border-l-4 border-blue-500">
            <div className="flex justify-between items-start mb-4">
              <h3 className="font-semibold text-gray-900">{model.name}</h3>
              <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(model.status)}`}>
                {model.status}
              </span>
            </div>
            
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Progress</span>
                  <span>{model.progress.toFixed(1)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-1000"
                    style={{ width: `${model.progress}%` }}
                  ></div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Epoch:</span>
                  <span className="ml-2 font-medium">{model.epoch}/{model.totalEpochs}</span>
                </div>
                <div>
                  <span className="text-gray-600">Loss:</span>
                  <span className="ml-2 font-medium">{model.loss.toFixed(3)}</span>
                </div>
                <div>
                  <span className="text-gray-600">Accuracy:</span>
                  <span className="ml-2 font-medium">{model.accuracy.toFixed(1)}%</span>
                </div>
                <div>
                  <span className="text-gray-600">ETA:</span>
                  <span className="ml-2 font-medium">{model.eta}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Training Metrics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Training & Validation Loss</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trainingData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="epoch" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="trainLoss" stroke="#3B82F6" name="Training Loss" strokeWidth={2} />
              <Line type="monotone" dataKey="valLoss" stroke="#EF4444" name="Validation Loss" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Training & Validation Accuracy</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={trainingData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="epoch" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="trainAcc" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.6} name="Training Accuracy" />
              <Area type="monotone" dataKey="valAcc" stackId="2" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.6} name="Validation Accuracy" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Real-time Logs */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Training Logs</h3>
        <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm h-64 overflow-y-auto">
          <div>[2024-09-04 10:15:23] Starting training for GPT-Style Transformer...</div>
          <div>[2024-09-04 10:15:24] Epoch 65/100 - Loss: 0.234 - Accuracy: 87.5% - Val Loss: 0.267 - Val Accuracy: 85.2%</div>
          <div>[2024-09-04 10:15:25] Learning rate adjusted to 0.0008</div>
          <div>[2024-09-04 10:15:26] Checkpoint saved at epoch 65</div>
          <div>[2024-09-04 10:15:27] GPU Memory Usage: 8.2GB / 16GB</div>
          <div>[2024-09-04 10:15:28] Training speed: 1.2 samples/sec</div>
          <div>[2024-09-04 10:15:29] ETA: 2h 15m remaining</div>
          <div>[2024-09-04 10:15:30] Batch 1250/1500 processed</div>
          <div className="text-yellow-400">[2024-09-04 10:15:31] Warning: High GPU temperature detected (82°C)</div>
          <div>[2024-09-04 10:15:32] Continuing training...</div>
        </div>
      </div>
    </div>
  );
};

export default TrainingMonitor;