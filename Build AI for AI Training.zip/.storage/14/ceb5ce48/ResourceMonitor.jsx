import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';

const ResourceMonitor = () => {
  const [systemMetrics, setSystemMetrics] = useState({
    cpu: 0,
    memory: 0,
    gpu: 0,
    storage: 0,
    network: 0
  });

  const [historicalData, setHistoricalData] = useState([]);
  const [gpuData, setGpuData] = useState([]);

  useEffect(() => {
    // Generate initial historical data
    const generateHistoricalData = () => {
      const data = [];
      const now = Date.now();
      for (let i = 23; i >= 0; i--) {
        data.push({
          time: new Date(now - i * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          cpu: Math.random() * 80 + 10,
          memory: Math.random() * 70 + 20,
          gpu: Math.random() * 90 + 5,
          network: Math.random() * 100
        });
      }
      return data;
    };

    setHistoricalData(generateHistoricalData());

    // Generate GPU data
    setGpuData([
      { name: 'GPU 1 (RTX 4090)', usage: 85, memory: 20, temperature: 78 },
      { name: 'GPU 2 (RTX 4090)', usage: 72, memory: 18, temperature: 74 },
      { name: 'GPU 3 (RTX 4090)', usage: 91, memory: 22, temperature: 82 },
      { name: 'GPU 4 (RTX 4090)', usage: 68, memory: 16, temperature: 71 }
    ]);

    // Simulate real-time updates
    const interval = setInterval(() => {
      setSystemMetrics({
        cpu: Math.random() * 80 + 10,
        memory: Math.random() * 70 + 20,
        gpu: Math.random() * 90 + 5,
        storage: Math.random() * 30 + 60,
        network: Math.random() * 100
      });

      setHistoricalData(prev => {
        const newData = [...prev.slice(1)];
        newData.push({
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          cpu: Math.random() * 80 + 10,
          memory: Math.random() * 70 + 20,
          gpu: Math.random() * 90 + 5,
          network: Math.random() * 100
        });
        return newData;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getUsageColor = (usage) => {
    if (usage < 50) return 'text-green-600';
    if (usage < 80) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getUsageBgColor = (usage) => {
    if (usage < 50) return 'bg-green-500';
    if (usage < 80) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const storageData = [
    { name: 'Used', value: systemMetrics.storage, fill: '#3B82F6' },
    { name: 'Free', value: 100 - systemMetrics.storage, fill: '#E5E7EB' }
  ];

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444'];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Resource Monitor</h2>
        <div className="flex space-x-3">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            📊 Export Report
          </button>
          <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            ⚙️ Configure Alerts
          </button>
        </div>
      </div>

      {/* Real-time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">CPU Usage</p>
              <p className={`text-2xl font-bold ${getUsageColor(systemMetrics.cpu)}`}>
                {systemMetrics.cpu.toFixed(1)}%
              </p>
            </div>
            <div className="text-3xl">🖥️</div>
          </div>
          <div className="mt-4 w-full bg-gray-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-1000 ${getUsageBgColor(systemMetrics.cpu)}`}
              style={{ width: `${systemMetrics.cpu}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Memory</p>
              <p className={`text-2xl font-bold ${getUsageColor(systemMetrics.memory)}`}>
                {systemMetrics.memory.toFixed(1)}%
              </p>
            </div>
            <div className="text-3xl">💾</div>
          </div>
          <div className="mt-4 w-full bg-gray-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-1000 ${getUsageBgColor(systemMetrics.memory)}`}
              style={{ width: `${systemMetrics.memory}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">GPU Usage</p>
              <p className={`text-2xl font-bold ${getUsageColor(systemMetrics.gpu)}`}>
                {systemMetrics.gpu.toFixed(1)}%
              </p>
            </div>
            <div className="text-3xl">🎮</div>
          </div>
          <div className="mt-4 w-full bg-gray-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-1000 ${getUsageBgColor(systemMetrics.gpu)}`}
              style={{ width: `${systemMetrics.gpu}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Storage</p>
              <p className={`text-2xl font-bold ${getUsageColor(systemMetrics.storage)}`}>
                {systemMetrics.storage.toFixed(1)}%
              </p>
            </div>
            <div className="text-3xl">💿</div>
          </div>
          <div className="mt-4 w-full bg-gray-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-1000 ${getUsageBgColor(systemMetrics.storage)}`}
              style={{ width: `${systemMetrics.storage}%` }}
            ></div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Network</p>
              <p className={`text-2xl font-bold ${getUsageColor(systemMetrics.network)}`}>
                {systemMetrics.network.toFixed(1)} MB/s
              </p>
            </div>
            <div className="text-3xl">🌐</div>
          </div>
          <div className="mt-4 w-full bg-gray-200 rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-1000 ${getUsageBgColor(systemMetrics.network)}`}
              style={{ width: `${systemMetrics.network}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Historical Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">System Usage Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={historicalData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="cpu" stroke="#3B82F6" name="CPU %" strokeWidth={2} />
              <Line type="monotone" dataKey="memory" stroke="#10B981" name="Memory %" strokeWidth={2} />
              <Line type="monotone" dataKey="gpu" stroke="#F59E0B" name="GPU %" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Storage Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={storageData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
                label={({ name, value }) => `${name}: ${value.toFixed(1)}%`}
              >
                {storageData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* GPU Details */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">GPU Cluster Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {gpuData.map((gpu, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-3">{gpu.name}</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Usage:</span>
                  <span className={`font-medium ${getUsageColor(gpu.usage)}`}>{gpu.usage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5">
                  <div 
                    className={`h-1.5 rounded-full ${getUsageBgColor(gpu.usage)}`}
                    style={{ width: `${gpu.usage}%` }}
                  ></div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Memory:</span>
                  <span className="font-medium">{gpu.memory}GB</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Temp:</span>
                  <span className={`font-medium ${gpu.temperature > 80 ? 'text-red-600' : 'text-green-600'}`}>
                    {gpu.temperature}°C
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* System Alerts */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">System Alerts</h3>
        <div className="space-y-3">
          <div className="flex items-center p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="text-yellow-600 mr-3">⚠️</div>
            <div>
              <p className="text-sm font-medium text-yellow-800">High GPU Temperature</p>
              <p className="text-xs text-yellow-600">GPU 3 temperature reached 82°C</p>
            </div>
          </div>
          <div className="flex items-center p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-blue-600 mr-3">ℹ️</div>
            <div>
              <p className="text-sm font-medium text-blue-800">Training Job Started</p>
              <p className="text-xs text-blue-600">New model training initiated on GPU cluster</p>
            </div>
          </div>
          <div className="flex items-center p-3 bg-green-50 border border-green-200 rounded-lg">
            <div className="text-green-600 mr-3">✅</div>
            <div>
              <p className="text-sm font-medium text-green-800">System Health Check Passed</p>
              <p className="text-xs text-green-600">All systems operating within normal parameters</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResourceMonitor;